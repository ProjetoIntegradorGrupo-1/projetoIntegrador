<?php

session_start();

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../Frontend/index.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['opcao'])) {
    header('Location: ../php/oqfazer.php');
    exit;
}

$opcao = $_POST['opcao'];
$perfil = $_SESSION['perfil_usuario'];

$rotas = [
    'cadastrar_usuario' => [
        'pagina' => '../../Frontend/caduser.html',
        'perfis' => ['administrador']
    ],

    'cadastrar_veiculo' => [
        'pagina' => '../../Frontend/cadcar.html',
        'perfis' => ['gestor']
    ],

    'criar_checklist' => [
        'pagina' => '../../Frontend/criarChecklist.html',
        'perfis' => ['gestor']
    ],

    'editar_usuario' => [
        'pagina' => '../../Frontend/editarUsuario.html',
        'perfis' => ['administrador']
    ],

    'editar_veiculo' => [
        'pagina' => '../../Frontend/editarVeiculo.html',
        'perfis' => ['gestor']
    ],

    'editar_checklist' => [
        'pagina' => '../../Frontend/editarChecklist.html',
        'perfis' => ['gestor']
    ],

    'excluir_usuario' => [
        'pagina' => '../../Frontend/excluirUsuario.html',
        'perfis' => ['administrador']
    ],

    'excluir_veiculo' => [
        'pagina' => '../../Frontend/excluirVeiculo.html',
        'perfis' => ['gestor']
    ],

    'excluir_checklist' => [
        'pagina' => '../../Frontend/excluirChecklist.html',
        'perfis' => ['gestor']
    ],

    'preencher_checklist' => [
        'pagina' => '../../Frontend/preencherChecklist.html',
        'perfis' => ['gestor', 'funcionario']
    ]
];

if (!isset($rotas[$opcao])) {
    header('Location: ../php/oqfazer.php?erro=opcao_invalida');
    exit;
}

$rota = $rotas[$opcao];

if (!in_array($perfil, $rota['perfis'], true)) {
    header('Location: ../php/oqfazer.php?erro=sem_permissao');
    exit;
}

header('Location: ' . $rota['pagina']);
exit;