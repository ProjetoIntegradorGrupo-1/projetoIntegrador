<?php

session_start();

require_once __DIR__ . '/../config/conexao.php';


/*
 * O cadastro só pode ser realizado por um administrador.
 */
if (
    !isset($_SESSION['id_usuario']) ||
    !isset($_SESSION['perfil_usuario']) ||
    $_SESSION['perfil_usuario'] !== 'administrador'
) {
    header('Location: ../../Frontend/index.html?erro=sem_permissao');
    exit;
}


/*
 * Só aceita requisições POST.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../Frontend/caduser.html');
    exit;
}


/*
 * Recebe os dados do formulário.
 */
$nome = trim($_POST['nome'] ?? '');
$sobrenome = trim($_POST['sobrenome'] ?? '');
$cpf = preg_replace('/\D/', '', $_POST['cpf'] ?? '');
$email = trim($_POST['email'] ?? '');
$perfil = $_POST['perfil'] ?? '';

$nome_completo = trim($nome . ' ' . $sobrenome);


/*
 * Validação dos campos obrigatórios.
 */
if (
    $nome === '' ||
    $sobrenome === '' ||
    $cpf === '' ||
    $email === '' ||
    $perfil === ''
) {
    header('Location: ../../Frontend/caduser.html?erro=campos_obrigatorios');
    exit;
}


/*
 * Validação do CPF.
 */
if (strlen($cpf) !== 11) {
    header('Location: ../../Frontend/caduser.html?erro=cpf_invalido');
    exit;
}


/*
 * Validação do e-mail.
 */
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ../../Frontend/caduser.html?erro=email_invalido');
    exit;
}


/*
 * Validação do perfil.
 */
$perfis_permitidos = [
    'administrador',
    'gestor',
    'funcionario'
];

if (!in_array($perfil, $perfis_permitidos, true)) {
    header('Location: ../../Frontend/caduser.html?erro=perfil_invalido');
    exit;
}


try {

    /*
     * Verifica duplicidade de CPF ou e-mail.
     */
    $sql = "
        SELECT id_usuario
        FROM Usuarios
        WHERE email = :email
           OR cpf = :cpf
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':email' => $email,
        ':cpf' => $cpf
    ]);

    if ($stmt->fetch()) {
        header('Location: ../../Frontend/caduser.html?erro=usuario_existente');
        exit;
    }


    /*
     * Senha inicial temporária.
     */
    $senha_temporaria = 'mudar123';

    $senha_hash = password_hash(
        $senha_temporaria,
        PASSWORD_DEFAULT
    );


    /*
     * Insere o usuário.
     */
    $sql = "
        INSERT INTO Usuarios (
            nome,
            cpf,
            email,
            senha,
            perfil,
            status
        )
        VALUES (
            :nome,
            :cpf,
            :email,
            :senha,
            :perfil,
            'ativo'
        )
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':nome' => $nome_completo,
        ':cpf' => $cpf,
        ':email' => $email,
        ':senha' => $senha_hash,
        ':perfil' => $perfil
    ]);


    header('Location: ../php/oqfazer.php?sucesso=usuario_cadastrado');
    exit;

} catch (PDOException $e) {

    /*
     * Registra o erro sem exibir detalhes
     * do banco para o usuário.
     */
    error_log($e->getMessage());

    header('Location: ../../Frontend/caduser.html?erro=erro_cadastro');
    exit;
}