<?php

require_once __DIR__ . '/config/conexao.php';

$stmt = $pdo->query("
    SELECT id_usuario, nome, email, perfil
    FROM Usuarios
");

$usuarios = $stmt->fetchAll();

foreach ($usuarios as $usuario) {
    echo "ID: " . $usuario['id_usuario'] . PHP_EOL;
    echo "Nome: " . $usuario['nome'] . PHP_EOL;
    echo "Email: " . $usuario['email'] . PHP_EOL;
    echo "Perfil: " . $usuario['perfil'] . PHP_EOL;
    echo "--------------------------" . PHP_EOL;
}