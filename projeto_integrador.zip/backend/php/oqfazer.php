<?php

session_start();

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../../Frontend/index.html');
    exit;
}

$nome_usuario = $_SESSION['nome_usuario'];
$perfil_usuario = $_SESSION['perfil_usuario'];

$opcoes = [];

if ($perfil_usuario === 'administrador') {

    $opcoes = [
        'cadastrar_usuario' => 'Cadastrar Usuário',
        'dashboard' => 'Visualizar Dashboard'
    ];

} elseif ($perfil_usuario === 'gestor') {

    $opcoes = [
        'criar_checklist' => 'Criar Checklist',
        'editar_checklist' => 'Editar Checklist',
        'preencher_checklist' => 'Preencher Checklist'
    ];

} elseif ($perfil_usuario === 'funcionario') {

    $opcoes = [
        'preencher_checklist' => 'Preencher Checklist'
    ];

} else {

    session_destroy();

    header('Location: ../../Frontend/index.html?erro=perfil_invalido');
    exit;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Menu Principal</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container d-flex justify-content-center align-items-center min-vh-100 py-4">

        <div class="card p-4 shadow-sm" style="max-width: 500px; width: 100%;">

            <h1 class="h4 text-center mb-1">
                Olá, <?= htmlspecialchars($nome_usuario) ?>!
            </h1>

            <p class="text-muted text-center small mb-4">
                Perfil: <?= htmlspecialchars($perfil_usuario) ?>
            </p>

            <form action="../checklist/processar_opcao.php" method="post">
                <fieldset class="mb-4">

                    <legend class="form-label fw-bold small text-primary mb-3">
                        O que você deseja fazer hoje?
                    </legend>

                    <?php foreach ($opcoes as $valor => $descricao): ?>

                        <div class="form-check mb-2">

                            <input class="form-check-input" type="radio" name="opcao" id="<?= htmlspecialchars($valor) ?>"
                                value="<?= htmlspecialchars($valor) ?>" required>

                            <label class="form-check-label" for="<?= htmlspecialchars($valor) ?>">
                                <?= htmlspecialchars($descricao) ?>
                            </label>

                        </div>

                    <?php endforeach; ?>

                </fieldset>

                <div class="d-grid gap-2">

                    <button type="submit" class="btn btn-primary">
                        Confirmar
                    </button>

                    <a href="../auth/logout.php" class="btn btn-outline-secondary">
                        Sair
                    </a>

                </div>

            </form>

        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>