<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

$host = $_ENV['DB_HOST'];
$port = $_ENV['DB_PORT'];
$database = $_ENV['DB_NAME'];
$username = $_ENV['DB_USER'];
$password = $_ENV['DB_PASSWORD'];
$caCert = $_ENV['DB_CA_CERT'];

try {
    $dsn = "mysql:"
        . "host={$host};"
        . "port={$port};"
        . "dbname={$database};"
        . "charset=utf8mb4;"
        . "sslmode=verify-ca;"
        . "sslrootcert={$caCert}";

    $pdo = new PDO(
        $dsn,
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

} catch (PDOException $e) {
    die(
        "Erro ao conectar ao banco de dados." . PHP_EOL .
        "Código: " . $e->getCode() . PHP_EOL .
        "Mensagem: " . $e->getMessage()
    );
}